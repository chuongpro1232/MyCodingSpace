package eeet2580.stress_test_5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StressTest5Application {

	public static void main(String[] args) {
		SpringApplication.run(StressTest5Application.class, args);
	}

}
