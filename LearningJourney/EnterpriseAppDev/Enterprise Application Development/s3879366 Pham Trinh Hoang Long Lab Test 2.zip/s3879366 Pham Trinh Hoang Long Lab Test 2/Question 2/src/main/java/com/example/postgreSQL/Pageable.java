package com.example.postgreSQL;

public interface Pageable {
}
