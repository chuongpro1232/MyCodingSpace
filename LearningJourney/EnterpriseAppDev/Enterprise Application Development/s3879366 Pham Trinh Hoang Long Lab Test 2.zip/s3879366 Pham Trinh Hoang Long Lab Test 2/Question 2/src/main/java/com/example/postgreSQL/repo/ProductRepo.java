package com.example.postgreSQL.repo;

import com.example.postgreSQL.model.Product;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface ProductRepo extends JpaRepository<Product, Long> {
    @Query("SELECT s FROM Product s WHERE s.name LIKE ?1")
    Page<Product> findByNameContaining(String name, Pageable pageable);

    @Query("SELECT s FROM Product s WHERE concat(s.id, '') LIKE ?1")
    Page<Product> findById(String id, Pageable pageable);

    @Query("SELECT s FROM Product s WHERE s.price >= ?1")
    Page<Product> findByMinPrice(String price, Pageable pageable);

    @Query("SELECT s FROM Product s WHERE s.price <= ?1")
    Page<Product> findByMaxPrice(String price, Pageable pageable);
}

