package com.example.postgreSQL.controller;

import com.example.postgreSQL.model.Product;

import com.example.postgreSQL.repo.ProductRepo;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class ProductController {
    @Autowired
    ProductRepo productRepo;

    private final int SERVICE_PER_PAGE = 10;

    public ProductController(ProductRepo productRepo) {
        this.productRepo = productRepo;
    }

    @PostConstruct
    public void initDB() {
        String[] category= {"Component", "Paint", "Finished Good"};
        List<Product> products = IntStream.rangeClosed(1, 100)
                .mapToObj(i -> new Product((long) new Random().nextInt(300),"product" + i, new Random().nextInt(10),"image", new Random().nextDouble(), category[new Random().nextInt(2)], "Bill of MAterial"))
                .collect(Collectors.toList());
        productRepo.saveAll(products);
    }

    @GetMapping("/product")
    public ResponseEntity getAllProducts(@RequestParam(required = false) String name, @RequestParam(required = false) String type,@RequestParam(required = false) String priceType, @RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "10") int size, @RequestParam(defaultValue = "id,asc") String[] sort) {
        try {
            List<Sort.Order> orders = new ArrayList<Sort.Order>();

            if (sort[0].contains(",")) {
                // will sort more than 2 columns
                for (String sortOrder : sort) {
                    // sortOrder="column, direction"
                    String[] _sort = sortOrder.split(",");
                    orders.add(new Sort.Order(getSortDirection(_sort[1]), _sort[0]));
                }
            } else {
                // sort=[column, direction]
                orders.add(new Sort.Order(getSortDirection(sort[1]), sort[0]));
            }

            List<Product> products = new ArrayList<Product>();
            Pageable paging = PageRequest.of(page, size);
            Pageable pagingSort = PageRequest.of(page, size, Sort.by(orders));

            Page<Product> pageServices;
            if (name == null)
                pageServices = productRepo.findAll(pagingSort);
            else {
                if (type.equals("id")) {
                    pageServices = productRepo.findById(name, pagingSort);
                }
                else if (type.equals("name")) {
                    pageServices = productRepo.findByNameContaining(name, pagingSort);
                }
                else {
                    if (priceType.equals("min")) {
                        pageServices = productRepo.findByMinPrice(name, pagingSort);
                    }
                    else {
                        pageServices = productRepo.findByMaxPrice(name, pagingSort);
                    }
                }
            }

            products = pageServices.getContent();

            Map<String, Object> response = new HashMap<>();
            response.put("services", products);
            response.put("currentPage", pageServices.getNumber());
            response.put("totalItems", pageServices.getTotalElements());
            response.put("totalPages", pageServices.getTotalPages());

//            return ResponseEntity.ok(this.serviceRepo.findAll());
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping(value = "/product/{id}/delete")
    @ResponseStatus(value = HttpStatus.OK)
    public ResponseEntity<HttpStatus> deleteProduct(@PathVariable("id") Long id, final RedirectAttributes redirectAttributes) {
        // delete the product
        try {
            productRepo.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/product/add")
    public ResponseEntity<Product> createProduct(@RequestBody Product product) {
        try {
            Product trans = productRepo.save( new Product(product.getId(), product.getName(), product.getUnit(), product.getImage(), product.getPrice(), product.getCategory(), product.getBillOfMaterial()));

            return new ResponseEntity<>(trans, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/product/{id}/edit")
    public ResponseEntity<Product> updateProduct(@PathVariable("id") long id, @RequestBody Product product) {
        Optional<Product> productData = productRepo.findById(id);

        if (productData.isPresent()) {
            Product products = productData.get();
            products.setId(product.getId());
            products.setPrice(product.getPrice());
            products.setUnit(product.getUnit());
            products.setName(product.getName());
            products.setCategory(product.getCategory());
            products.setImage(product.getImage());
            products.setBillOfMaterial(product.getBillOfMaterial());
            return new ResponseEntity<>(productRepo.save(products), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    private Sort.Direction getSortDirection(String direction) {
        if (direction.equals("asc")) {
            return Sort.Direction.ASC;
        } else if (direction.equals("desc")) {
            return Sort.Direction.DESC;
        }

        return Sort.Direction.ASC;
    }
}
