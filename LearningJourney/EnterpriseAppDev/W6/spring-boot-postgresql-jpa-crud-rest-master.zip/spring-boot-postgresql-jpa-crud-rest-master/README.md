# Spring Boot Postgresql JPA CRUD REST

![alt text](https://techburps-7.s3.ap-south-1.amazonaws.com/tech-blog/spring-boot-rest-swagger.png)

Documentation: https://www.codeburps.com/post/spring-boot-rest-api-with-postgre-sql
