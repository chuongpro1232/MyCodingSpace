package eeet2580.stress_test_4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StressTest4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
