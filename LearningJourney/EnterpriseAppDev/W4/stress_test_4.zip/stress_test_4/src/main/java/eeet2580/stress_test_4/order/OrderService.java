package eeet2580.stress_test_4.order;

import org.springframework.beans.factory.annotation.Autowired;

public class OrderService {
    
    String getOrderByUserId(int userId) {
        return "order00001";
    }
}
