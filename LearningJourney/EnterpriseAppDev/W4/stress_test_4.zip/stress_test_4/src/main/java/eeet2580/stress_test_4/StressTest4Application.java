package eeet2580.stress_test_4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StressTest4Application {

	public static void main(String[] args) {
		SpringApplication.run(StressTest4Application.class, args);
	}

}
