/*
  RMIT University Vietnam
  Course: INTE2512 Object-Oriented Programming
  Semester: 2023A
  Assessment: Test 1
  Author: Tran Thanh Tu
  ID: S3957386
  Created  date: 15/04/2023
  Acknowledgement: None
*/

package Test1;

public class TechnicalStaffs extends Staffs {

}
